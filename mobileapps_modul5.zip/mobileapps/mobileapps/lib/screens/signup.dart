import 'package:flutter/material.dart';
import 'package:mobileapps/theme/theme.dart';
import 'package:icons_plus/icons_plus.dart';
import 'package:mobileapps/widgets/custom_scaffold.dart';
import 'package:mobileapps/screens/signin.dart';

class Signup extends StatefulWidget {
  const Signup({super.key});

  @override
  State<Signup> createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  final _formSignupKey = GlobalKey<FormState>();
  bool agreePersonalData = true;

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      child: Column(
        children: [
          const Expanded(flex: 1, child: SizedBox(height: 10)),
          Expanded(
            flex: 7,
            child: Container(
              padding: const EdgeInsets.fromLTRB(25.0, 50.0, 25.0, 20.0),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40.0),
                  topRight: Radius.circular(40.0),
                ),
              ),
              child: SingleChildScrollView(
                child: Form(
                  key: _formSignupKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      _buildTitle(),
                      const SizedBox(height: 40.0),
                      _buildTextField('Full Name', 'Enter Full Name', false),
                      const SizedBox(height: 25.0),
                      _buildTextField('Email', 'Enter Email', false),
                      const SizedBox(height: 25.0),
                      _buildTextField('Password', 'Enter Password', true),
                      const SizedBox(height: 25.0),
                      _buildAgreementCheckbox(),
                      const SizedBox(height: 25.0),
                      _buildSignUpButton(),
                      const SizedBox(height: 30.0),
                      _buildDividerWithText('Sign up with'),
                      const SizedBox(height: 30.0),
                      _buildSignInOption(),
                      const SizedBox(height: 20.0),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTitle() {
    return Text(
      'Get Started',
      style: TextStyle(
        fontSize: 30.0,
        fontWeight: FontWeight.w900,
        color: lightColorScheme.onSurface,
      ),
    );
  }

  Widget _buildTextField(String label, String hint, bool isPassword) {
    return TextFormField(
      obscureText: isPassword,
      obscuringCharacter: '*',
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter $label';
        }
        return null;
      },
      decoration: InputDecoration(
        label: Text(label),
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.black26),
        border: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.black12),
          borderRadius: BorderRadius.circular(10),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.black12),
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  Widget _buildAgreementCheckbox() {
    return Row(
      children: [
        Checkbox(
          value: agreePersonalData,
          onChanged: (bool? value) {
            setState(() {
              agreePersonalData = value!;
            });
          },
          activeColor: lightColorScheme.primary,
        ),
        const Text('I agree to the processing of ',
            style: TextStyle(color: Colors.black45)),
        Text('Personal data',
            style: TextStyle(
                fontWeight: FontWeight.bold,
                color: lightColorScheme.primary)),
      ],
    );
  }

  Widget _buildSignUpButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () {
          if (_formSignupKey.currentState!.validate() && agreePersonalData) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Processing Data')),
            );
          } else if (!agreePersonalData) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Please agree to the processing of personal data'),
              ),
            );
          }
        },
        child: const Text('Sign up'),
      ),
    );
  }

  Widget _buildDividerWithText(String text) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Expanded(child: Divider(thickness: 0.7, color: Colors.grey.withOpacity(0.5))),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Text(text, style: const TextStyle(color: Colors.black45)),
        ),
        Expanded(child: Divider(thickness: 0.7, color: Colors.grey.withOpacity(0.5))),
      ],
    );
  }

  Widget _buildSignInOption() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text("Already have an account? ", style: TextStyle(color: Colors.black45)),
        GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const Signin()),
            );
          },
          child: Text(
            'Sign in',
            style: TextStyle(fontWeight: FontWeight.bold, color: lightColorScheme.primary),
          ),
        ),
      ],
    );
  }
}
